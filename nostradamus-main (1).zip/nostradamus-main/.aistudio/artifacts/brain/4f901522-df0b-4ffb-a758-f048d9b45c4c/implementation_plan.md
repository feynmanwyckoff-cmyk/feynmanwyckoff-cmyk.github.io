# Sistem Keamanan Sandi Terminal (Web Crypto SHA-256 & AES-256-GCM) + Penyempurnaan Tata Letak Tabel & Footer

Implementasi sistem autentikasi **Zero-Knowledge Terminal Security Gate** berbasis **Web Crypto API (`PBKDF2-SHA256` & `AES-256-GCM`)** yang mengunci penuh akses terminal sejak awal dibuka dan selalu meminta sandi setiap kali halaman di-*refresh* atau ditutup, sekaligus menyempurnakan jarak kontainer ke footer (`8px–12px`), tinggi minimum tabel saat hasil filter 1 baris, dan *portal tooltip* bebas terpotong.

## User Review & Critical Decisions

> [!IMPORTANT]
> Seluruh keputusan desain dan mekanisme keamanan berikut telah dikonfirmasi sesuai pilihan Anda:

- **Keputusan Terkonfirmasi 1 (Mekanisme Sandi & Enkripsi Portofolio)**: Menggunakan **Web Crypto API (`SubtleCrypto`)** dengan **PBKDF2-SHA256 (100.000 iterasi + *salt* acak)** untuk verifikasi sandi tanpa pernah menyimpan sandi asli (*plaintext*), serta **AES-256-GCM** untuk mengenkripsi data sensitif portofolio (`holdings` lot/harga beli dan `cashReserveIdr` cadangan kas) di penyimpanan lokal maupun di berkas `nostradamus_cloud_state.json`.
- **Keputusan Terkonfirmasi 2 (Cakupan Kunci Penuh Sejak Awal)**: Mengunci penuh seluruh tampilan **Nostradamus Quant Terminal** sejak pertama kali alamat web dibuka sebelum pengguna dapat melihat atau mengakses halaman utama.
- **Keputusan Terkonfirmasi 3 (Kebijakan Sesi Ketat — Selalu Minta Sandi Saat Refresh/Tutup Tab)**: Kunci kriptografi yang telah dibuka hanya disimpan di memori RAM sementara (*in-memory React state*) dan **tidak** disimpan di `sessionStorage`/`localStorage`. Setiap kali halaman di-*refresh* (`F5`) atau tab browser ditutup/dibuka kembali, terminal otomatis terkunci kembali. Tersedia juga tombol **Kunci Terminal (Lock)** dan **Ubah Sandi** di bagian header.
- **Keputusan Terkonfirmasi 4 (Tata Letak Tabel 1 Baris, Tooltip & Jarak Footer)**:
  - Jarak antara batas bawah kontainer utama dan bar footer dirapatkan menjadi `8px–12px` saat *scroll* mentok ke bawah.
  - Tabel *Screener* diberi tinggi minimum yang proporsional (`min-h-[260px]`) agar tidak menciut sempit saat hasil filter hanya 1 baris.
  - `MetricTooltip` dirender melalui *portal fixed positioning* (`document.body`) agar tampil utuh tanpa terpotong batas tabel.

---

## 1. Overview & Core Concept

- **What It Does**:
  1. **Full-Screen Terminal Security Gate**: Menampilkan layar verifikasi sandi bergaya institusional sebelum komponen terminal dirender. Saat pertama kali dijalankan (jika belum ada *vault* sandi di perangkat/cloud), pengguna membuat **Master Sandi Terminal** untuk mengenkripsi portofolio mereka; pada kunjungan berikutnya atau setiap kali *refresh*, pengguna wajib memasukkan sandi tersebut untuk mendekripsi portofolio dan membuka terminal.
  2. **Enkripsi Portofolio AES-256-GCM (Lokal & GitHub Cloud Sync)**: Menyimpan daftar posisi saham (`holdings`) dan kas (`cashReserveIdr`) dalam bentuk *ciphertext* AES-256-GCM yang terikat pada sandi pengguna, sehingga privasi nilai portofolio tetap terlindungi meskipun file JSON di repositori GitHub diakses pihak luar.
  3. **Perbaikan Visual Tabel, Tooltip & Footer**: Merapatkan jarak kontainer ke footer menjadi `8px–12px`, menjaga tinggi minimum tabel saat hasil filter sedikit, dan membebaskan *hover tooltip* dari pemotongan `overflow`.
- **Target Audience / Persona**: Pemilik portofolio internal yang membutuhkan privasi penuh atas posisi lot dan nilai ekuitasnya di GitHub Pages maupun perangkat lokal.
- **Key Value**: Keamanan kriptografi standar perbankan (*AES-256-GCM* + *PBKDF2-SHA256*) tanpa backend eksternal, dipadukan dengan antarmuka kuantitatif yang rapi dan presisi.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **Inisialisasi Sandi Pertama Kali (First-Time Vault Setup)**:
     - Jika belum ada konfigurasi sandi di `localStorage` maupun di `nostradamus_cloud_state.json`, layar kunci menampilkan mode **Aktivasi Sandi Terminal Internal** (Input Sandi Baru + Konfirmasi Sandi).
     - Begitu disimpan, sistem menurunkan kunci `AES-256-GCM` via `PBKDF2`, mengenkripsi data portofolio saat ini, dan membuka terminal.
  2. **Verifikasi Sandi Setiap Buka / Refresh Halaman**:
     - Setiap kali halaman dibuka atau di-*refresh*, pengguna disambut oleh layar **Verifikasi Akses Terminal Internal**.
     - Pengguna memasukkan sandi -> sistem menguji kecocokan *salted verifier* & mendekripsi *vault* portofolio -> terminal terbuka. Jika salah, muncul pesan peringatan tanpa membuka data apa pun.
  3. **Kunci Instan & Ubah Sandi dari Header**:
     - Di bar header atas terdapat tombol **Lock** (mengunci terminal seketika tanpa perlu *refresh*) dan tombol **Sandi** (membuka modal untuk mengganti sandi lama ke sandi baru sekaligus mengenkripsi ulang *vault* portofolio).
  4. **Filter Tabel 1 Baris & Hover Tooltip**:
     - Saat mencari 1 saham (misal `sini`), tabel tetap memanjang proporsional mendekati footer (`min-h-[260px]`), *tooltip* tampil utuh di atas tabel, dan jarak akhir *scroll* ke footer rapat di `8px–12px`.
- **Visual Identity & Theme**:
  - *Aesthetic Direction*: Mengikuti tema aktif (*Daylight Mode* `#F4F5F7`/`#FFFFFF` atau *Dark Terminal* `#090C10`/`#11161F`) dengan aksen emas/amber `#D97706`/`#F59E0B` dan tipografi `Montserrat` + `tabular-nums`.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: In-Memory Session Only (Selalu Minta Sandi Saat Refresh)**
  - *Chosen Approach*: Menyimpan status `isUnlocked` dan `CryptoKey` murni di memori React (`useState`), tanpa menyimpannya ke `sessionStorage` atau `localStorage`.
  - *Why*: Sesuai permintaan Anda, begitu halaman di-*refresh* atau tab ditutup, memori RAM dibersihkan otomatis oleh browser sehingga sandi wajib dimasukkan kembali.
- **Decision 2: PBKDF2 (100.000 Iterasi) + AES-256-GCM via Native Web Crypto API**
  - *Chosen Approach*: Menggunakan `window.crypto.subtle` bawaan browser modern tanpa pustaka kriptografi pihak ketiga yang berat.
  - *Why*: Aman dari serangan *brute-force* ringan, tidak meninggalkan sandi *plaintext* di kode sumber, dan kompatibel 100% dengan arsitektur statis GitHub Pages.
- **Decision 3: Portal-Based Fixed Positioning untuk `MetricTooltip` & Min-Height Tabel**
  - *Chosen Approach*: Merender *tooltip* ke `document.body` dengan `position: fixed` terhitung dari `getBoundingClientRect()` dan menetapkan `min-h-[260px]` pada `.table-scroll-container`.
  - *Why*: Menghilangkan masalah *tooltip* terpotong saat tabel hanya berisi 1 baris dan mencegah celah kosong besar di atas footer.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

- **Architecture & Component Diagram**:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│ App Root (In-Memory CryptoKey & isUnlocked State)                           │
│                                                                             │
│  ├─ [IF !isUnlocked] ──> TerminalSecurityGate (Full-Screen Lock View)       │
│  │    ├─ Mode A: Unlock Terminal (Verify PBKDF2-SHA256 & Decrypt AES-256)   │
│  │    └─ Mode B: First-Time / Change Passphrase Setup                       │
│  │                                                                          │
│  └─ [IF isUnlocked] ───> Authenticated Quant Terminal Workspace             │
│       ├─ Top Header (Includes Instant "Lock" & "Ubah Sandi" Controls)       │
│       ├─ Main Container (pt-4 pb-2 -> 8px–12px tight gap to Sticky Footer)  │
│       │   ├─ ScreeningTable (.table-scroll-container min-h-[260px])         │
│       │   └─ ActivePortfolioManager (Reads/Writes AES-256 Encrypted Vault)  │
│       ├─ Sticky Bottom Footer (mt-1)                                        │
│       └─ Document Body Portal -> MetricTooltip (Fixed Unclipped Overlay)    │
└─────────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State (`EncryptedPortfolioVault`)**:
  - Struktur metadata keamanan yang disimpan di `localStorage` dan disinkronkan di `CloudStateBundle` (`nostradamus_cloud_state.json`):
    - `saltBase64`: *Random salt* 16-byte untuk derivasi kunci `PBKDF2-SHA256`.
    - `verifierHashBase64`: Hash verifikasi SHA-256 untuk memvalidasi kebenaran sandi secara instan.
    - `ivBase64`: *Initialization Vector* 12-byte untuk `AES-256-GCM`.
    - `cipherTextBase64`: Payload terenkripsi yang memuat `{ holdings, cashReserveIdr, capitalIdr }`.
  - Saat *vault* aktif di dalam berkas `nostradamus_cloud_state.json`, field `holdings` plaintext di-kosongkan atau digantikan oleh `encryptedVault` sehingga privasi portofolio di GitHub tetap terjaga penuh.
