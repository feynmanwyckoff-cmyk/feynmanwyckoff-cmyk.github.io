import { EncryptedPortfolioVault, PortfolioHolding } from '../types/quant';

const VAULT_STORAGE_KEY = 'nostradamus_aes256_security_vault_v1';
const PBKDF2_ITERATIONS = 100000;

export interface VaultSensitivePayload {
  holdings: PortfolioHolding[];
  cashReserveIdr: number;
  capitalIdr: number;
}

export interface ActiveVaultSession {
  aesKey: CryptoKey;
  saltBase64: string;
  verifierHashBase64: string;
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function base64ToBytes(base64Str: string): Uint8Array {
  const clean = base64Str.replace(/\s/g, '');
  const binary = atob(clean);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/**
 * Derives a 256-bit AES-GCM key and a separate 256-bit SHA-256 verification hash
 * from a user passphrase and 128-bit salt using Web Crypto PBKDF2-SHA256 (100,000 iterations).
 * Plaintext passphrase is never stored anywhere.
 */
export async function deriveVaultKeyAndVerifier(
  passphrase: string,
  saltBytes: Uint8Array
): Promise<{ aesKey: CryptoKey; verifierHashBase64: string }> {
  const enc = new TextEncoder();
  const baseKey = await window.crypto.subtle.importKey(
    'raw',
    enc.encode(passphrase),
    'PBKDF2',
    false,
    ['deriveBits', 'deriveKey']
  );

  // Derive 512 bits (64 bytes): first 32 bytes for AES-256-GCM key, next 32 bytes for SHA-256 verifier
  const derivedBits = await window.crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: saltBytes as unknown as BufferSource,
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256'
    },
    baseKey,
    512
  );

  const allBytes = new Uint8Array(derivedBits);
  const aesKeyBytes = allBytes.slice(0, 32);
  const verifierRawBytes = allBytes.slice(32, 64);

  const aesKey = await window.crypto.subtle.importKey(
    'raw',
    aesKeyBytes,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );

  const verifierDigest = await window.crypto.subtle.digest('SHA-256', verifierRawBytes);
  const verifierHashBase64 = bytesToBase64(new Uint8Array(verifierDigest));

  return { aesKey, verifierHashBase64 };
}

/**
 * Encrypts sensitive portfolio data using an already derived in-memory AES-256-GCM key.
 */
export async function encryptPortfolioWithSession(
  session: ActiveVaultSession,
  payload: VaultSensitivePayload
): Promise<EncryptedPortfolioVault> {
  const ivBytes = window.crypto.getRandomValues(new Uint8Array(12));
  const encodedPayload = new TextEncoder().encode(JSON.stringify(payload));

  const cipherBuffer = await window.crypto.subtle.encrypt(
    {
      name: 'AES-GCM',
      iv: ivBytes
    },
    session.aesKey,
    encodedPayload
  );

  return {
    version: 1,
    saltBase64: session.saltBase64,
    verifierHashBase64: session.verifierHashBase64,
    ivBase64: bytesToBase64(ivBytes),
    cipherTextBase64: bytesToBase64(new Uint8Array(cipherBuffer)),
    updatedAt: new Date().toISOString()
  };
}

/**
 * Creates a brand-new encrypted portfolio vault from a new passphrase.
 */
export async function createEncryptedVaultFromPassphrase(
  passphrase: string,
  payload: VaultSensitivePayload
): Promise<{ vault: EncryptedPortfolioVault; session: ActiveVaultSession }> {
  const saltBytes = window.crypto.getRandomValues(new Uint8Array(16));
  const saltBase64 = bytesToBase64(saltBytes);
  const { aesKey, verifierHashBase64 } = await deriveVaultKeyAndVerifier(passphrase, saltBytes);

  const session: ActiveVaultSession = {
    aesKey,
    saltBase64,
    verifierHashBase64
  };

  const vault = await encryptPortfolioWithSession(session, payload);
  return { vault, session };
}

/**
 * Verifies the passphrase against the salted SHA-256 verifier and decrypts the AES-256-GCM portfolio payload.
 */
export async function unlockAndDecryptVault(
  passphrase: string,
  vault: EncryptedPortfolioVault
): Promise<{ payload: VaultSensitivePayload; session: ActiveVaultSession }> {
  const saltBytes = base64ToBytes(vault.saltBase64);
  const { aesKey, verifierHashBase64 } = await deriveVaultKeyAndVerifier(passphrase, saltBytes);

  if (verifierHashBase64 !== vault.verifierHashBase64) {
    throw new Error('INVALID_PASSPHRASE');
  }

  const ivBytes = base64ToBytes(vault.ivBase64);
  const cipherBytes = base64ToBytes(vault.cipherTextBase64);

  try {
    const plainBuffer = await window.crypto.subtle.decrypt(
      {
        name: 'AES-GCM',
        iv: ivBytes as unknown as BufferSource
      },
      aesKey,
      cipherBytes as unknown as BufferSource
    );

    const decodedStr = new TextDecoder().decode(plainBuffer);
    const parsed = JSON.parse(decodedStr) as VaultSensitivePayload;

    return {
      payload: {
        holdings: Array.isArray(parsed.holdings) ? parsed.holdings : [],
        cashReserveIdr: typeof parsed.cashReserveIdr === 'number' ? parsed.cashReserveIdr : 0,
        capitalIdr: typeof parsed.capitalIdr === 'number' ? parsed.capitalIdr : 100000000
      },
      session: {
        aesKey,
        saltBase64: vault.saltBase64,
        verifierHashBase64: vault.verifierHashBase64
      }
    };
  } catch {
    throw new Error('DECRYPTION_FAILED');
  }
}

export function loadLocalSecurityVault(): EncryptedPortfolioVault | null {
  try {
    const raw = localStorage.getItem(VAULT_STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as EncryptedPortfolioVault;
    if (
      parsed &&
      parsed.version === 1 &&
      typeof parsed.saltBase64 === 'string' &&
      typeof parsed.verifierHashBase64 === 'string' &&
      typeof parsed.ivBase64 === 'string' &&
      typeof parsed.cipherTextBase64 === 'string'
    ) {
      return parsed;
    }
    return null;
  } catch {
    return null;
  }
}

export function saveLocalSecurityVault(vault: EncryptedPortfolioVault): void {
  try {
    localStorage.setItem(VAULT_STORAGE_KEY, JSON.stringify(vault));
  } catch {
    // ignore storage errors
  }
}
